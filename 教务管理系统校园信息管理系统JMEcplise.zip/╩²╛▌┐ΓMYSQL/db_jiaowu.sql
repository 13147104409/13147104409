/*
MySQL Data Transfer
Source Host: localhost
Source Database: db_jiaowu
Target Host: localhost
Target Database: db_jiaowu
Date: 2020-07-20 16:17:10
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for t_admin
-- ----------------------------
CREATE TABLE `t_admin` (
  `userId` int(11) NOT NULL auto_increment COMMENT '用户id',
  `userName` varchar(50) default NULL COMMENT '用户名(登录用户名)',
  `userPw` varchar(50) default NULL COMMENT '密码',
  `xingming` varchar(255) default NULL,
  PRIMARY KEY  (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_banji
-- ----------------------------
CREATE TABLE `t_banji` (
  `id` int(11) NOT NULL auto_increment COMMENT '专业id',
  `mingcheng` varchar(255) default NULL COMMENT '专业名称',
  `del` int(11) default NULL COMMENT '是否删除',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_chengji
-- ----------------------------
CREATE TABLE `t_chengji` (
  `id` int(11) NOT NULL auto_increment COMMENT '成绩编号',
  `xueshengId` int(11) default NULL COMMENT '(外键)学生编号',
  `kaoshishi` varchar(255) default NULL COMMENT '考试时间',
  `kechengId` int(255) default NULL COMMENT '(外键)课程编号',
  `fenshu` decimal(10,1) default NULL COMMENT '分数',
  PRIMARY KEY  (`id`),
  KEY `FK_xuesheng_chengji` (`xueshengId`),
  KEY `FK_kecheng_chengji` (`kechengId`),
  CONSTRAINT `FK_kecheng_chengji` FOREIGN KEY (`kechengId`) REFERENCES `t_kecheng` (`id`),
  CONSTRAINT `FK_xuesheng_chengji` FOREIGN KEY (`xueshengId`) REFERENCES `t_xuesheng` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_gonggao
-- ----------------------------
CREATE TABLE `t_gonggao` (
  `id` int(11) NOT NULL auto_increment COMMENT '公告编号',
  `title` varchar(255) default NULL COMMENT '公告标题',
  `content` varchar(255) default NULL COMMENT '公告内容',
  `addtime` varchar(255) default NULL COMMENT '发布时间',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_kaoqin
-- ----------------------------
CREATE TABLE `t_kaoqin` (
  `id` int(11) NOT NULL auto_increment,
  `xsmc` varchar(255) default NULL,
  `banjiid` int(11) default NULL,
  `jsmc` varchar(255) default NULL,
  `shijian` varchar(255) default NULL,
  `result` varchar(255) default NULL,
  `type` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_kebiao
-- ----------------------------
CREATE TABLE `t_kebiao` (
  `id` int(11) NOT NULL auto_increment,
  `banjiid` int(11) default NULL,
  `kechengid` int(11) default NULL,
  `laoshiid` int(11) default NULL,
  `zhouid` int(11) default NULL,
  `shijian` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_kecheng
-- ----------------------------
CREATE TABLE `t_kecheng` (
  `id` int(11) NOT NULL auto_increment COMMENT '课程编号',
  `mingcheng` varchar(255) default NULL COMMENT '课程名称',
  `banjiid` int(11) default NULL COMMENT '(外键)所属专业',
  `del` int(11) default NULL COMMENT '是否删除',
  PRIMARY KEY  (`id`),
  KEY `FK_zhuanye_kecheng` (`banjiid`),
  CONSTRAINT `FK_zhuanye_kecheng` FOREIGN KEY (`banjiid`) REFERENCES `t_banji` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_laoshi
-- ----------------------------
CREATE TABLE `t_laoshi` (
  `id` int(11) NOT NULL auto_increment COMMENT '老师id',
  `bianhao` varchar(55) default NULL COMMENT '老师编号(登录用户名)',
  `xingming` varchar(55) default NULL COMMENT '老师姓名',
  `xingbie` varchar(50) default NULL COMMENT '老师性别',
  `nianling` varchar(50) default NULL COMMENT '老师年龄',
  `loginpw` varchar(50) default NULL COMMENT '老师密码',
  `banjiid` int(11) default NULL COMMENT '(外键)所属专业',
  `status` int(11) default NULL COMMENT '是否审核',
  `del` int(11) default NULL COMMENT '是否删除',
  PRIMARY KEY  (`id`),
  KEY `FK_zhuanye_laoshi` (`banjiid`),
  CONSTRAINT `FK_zhuanye_laoshi` FOREIGN KEY (`banjiid`) REFERENCES `t_banji` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_message
-- ----------------------------
CREATE TABLE `t_message` (
  `id` int(11) NOT NULL auto_increment,
  `xsmc` varchar(255) default NULL,
  `banjiid` int(11) default NULL,
  `content` varchar(255) default NULL,
  `lytime` varchar(255) default NULL,
  `reply` varchar(255) default NULL,
  `lsmc` varchar(255) default NULL,
  `rtime` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_pingjia
-- ----------------------------
CREATE TABLE `t_pingjia` (
  `id` int(11) NOT NULL auto_increment,
  `xsmc` varchar(255) default NULL,
  `banjiid` int(11) default NULL,
  `jsmc` varchar(255) default NULL,
  `shijian` varchar(255) default NULL,
  `result` varchar(255) default NULL,
  `type` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for t_xuesheng
-- ----------------------------
CREATE TABLE `t_xuesheng` (
  `id` int(11) NOT NULL auto_increment COMMENT '学生id',
  `banjiid` int(11) default NULL COMMENT '(外键)专业编号',
  `xuehao` varchar(255) default NULL COMMENT '学号(登录用户名)',
  `xingming` varchar(255) default NULL COMMENT '姓名',
  `xingbie` varchar(255) default NULL COMMENT '性别',
  `nianling` varchar(255) default NULL COMMENT '年龄',
  `loginpw` varchar(255) default NULL COMMENT '登录密码',
  `status` int(11) default NULL COMMENT '是否审核',
  `del` int(11) default NULL COMMENT '是否删除',
  PRIMARY KEY  (`id`),
  KEY `FK_zhuanye` (`banjiid`),
  CONSTRAINT `FK_zhuanye` FOREIGN KEY (`banjiid`) REFERENCES `t_banji` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `t_admin` VALUES ('1', 'admin', '123', '管理员');
INSERT INTO `t_banji` VALUES ('1', '17301班', '0');
INSERT INTO `t_banji` VALUES ('2', '17302班', '0');
INSERT INTO `t_banji` VALUES ('3', '17303班', '0');
INSERT INTO `t_banji` VALUES ('4', '17304班', '0');
INSERT INTO `t_chengji` VALUES ('1', '2', '2020-07-02', '1', '98.0');
INSERT INTO `t_chengji` VALUES ('2', '2', '2020-07-02', '2', '98.0');
INSERT INTO `t_chengji` VALUES ('3', '3', '2020-07-02', '2', '80.0');
INSERT INTO `t_chengji` VALUES ('4', '4', '2020-07-02', '3', '90.0');
INSERT INTO `t_chengji` VALUES ('5', '4', '2020-07-02', '4', '98.0');
INSERT INTO `t_gonggao` VALUES ('1', '今天下午有计算机基础考试', '今天下午有计算机基础考试，请大家14:00到二教室进行考试。', '2020-07-02');
INSERT INTO `t_gonggao` VALUES ('3', '暑假放假最新通知', '今年暑假放假时间定为6-25日至9-1日，希望大家认真复习，做好期末考试准备。', '2020-07-02');
INSERT INTO `t_kaoqin` VALUES ('2', null, null, '张盛辉', '2020-07-02 11:11:44', '早退', '0');
INSERT INTO `t_kaoqin` VALUES ('3', null, null, '陈强', '2020-07-02 11:12:00', '正常', '0');
INSERT INTO `t_kaoqin` VALUES ('4', null, null, '张盛辉', '2020-07-02 11:12:10', '请假', '0');
INSERT INTO `t_kaoqin` VALUES ('7', '刘三', '1', null, '2020-07-02 11:23:42', '正常', '1');
INSERT INTO `t_kaoqin` VALUES ('8', '刘三', '1', null, '2020-07-0211:23:49', '正常', '1');
INSERT INTO `t_kaoqin` VALUES ('9', '刘三', '1', null, '2020-07-02 11:23:57', '正常', '1');
INSERT INTO `t_kaoqin` VALUES ('10', '赵刚', '2', null, '2020-07-02 17:30:12', '迟到', '1');
INSERT INTO `t_kebiao` VALUES ('1', '1', '1', '1', '1', '08:00-10:00');
INSERT INTO `t_kecheng` VALUES ('1', '计算机组成原理', '1', '0');
INSERT INTO `t_kecheng` VALUES ('2', 'Java程序设计', '1', '0');
INSERT INTO `t_kecheng` VALUES ('3', '通讯原理', '2', '0');
INSERT INTO `t_kecheng` VALUES ('4', '会计电算化', '3', '0');
INSERT INTO `t_laoshi` VALUES ('1', '0005', '陈强', '男', '30', '123', '1', '1', '0');
INSERT INTO `t_laoshi` VALUES ('2', '0001 ', '李强强', '男', '45', '123', '4', '1', '0');
INSERT INTO `t_laoshi` VALUES ('3', '0002', '张盛辉', '男', '20', '123', '2', '1', '0');
INSERT INTO `t_laoshi` VALUES ('4', '0003', '刘诗诗', '女', '29', '123', '3', '1', '0');
INSERT INTO `t_laoshi` VALUES ('5', '0004', '王晶', '女', '34', '123', '1', '1', '0');
INSERT INTO `t_message` VALUES ('1', '刘三', '1', '我有个问题要问', '2020-07-02 22:39:36', '你的问题还没说', '陈强', '2018-04-08 22:54:10');
INSERT INTO `t_message` VALUES ('2', '刘三', '1', '大家好', '2020-07-02 17:31:23', null, null, null);
INSERT INTO `t_pingjia` VALUES ('4', null, null, '刘诗诗', '2020-07-02', '优秀班主任', '0');
INSERT INTO `t_pingjia` VALUES ('5', '刘三', '1', null, '2020-07-02', '三好学生', '1');
INSERT INTO `t_xuesheng` VALUES ('2', '1', '2017001', '刘三', '男', '21', '123', '1', '0');
INSERT INTO `t_xuesheng` VALUES ('3', '2', '2017002', '赵刚', '男', '14', '123', '1', '0');
INSERT INTO `t_xuesheng` VALUES ('4', '3', '2017003', '李强', '男', '13', '123', '1', '0');
INSERT INTO `t_xuesheng` VALUES ('8', '4', '2017004', '李四', '女', '20', '123', '1', '0');
INSERT INTO `t_xuesheng` VALUES ('10', '1', '2017005', '刘晶', '女', '23', '123', '1', '0');
