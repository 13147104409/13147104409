package cn.jiaowu.dao;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.jiaowu.entity.Chengji;
import cn.jiaowu.entity.Kaoqin;
import cn.jiaowu.entity.Pingjia;

public interface PingjiaDao {
	int deleteByPrimaryKey(Integer id);

    int insert(Pingjia record);

    int updateByPrimaryKeySelective(Pingjia record);
    
    List<Pingjia> getAll(@Param("banjiid") Integer banjiid,@Param("xsmc") String xsmc,@Param("jsmc") String jsmc);
    List<Pingjia> getAllByType(Integer type);
}