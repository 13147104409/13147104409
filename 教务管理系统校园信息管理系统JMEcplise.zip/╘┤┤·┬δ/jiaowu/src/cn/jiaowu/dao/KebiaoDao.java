package cn.jiaowu.dao;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.jiaowu.entity.Chengji;
import cn.jiaowu.entity.Kebiao;

public interface KebiaoDao {
	int deleteByPrimaryKey(Integer id);

    int insert(Kebiao record);

    int updateByPrimaryKeySelective(Kebiao record);
    
    List<Kebiao> getAll(@Param("banjiid") Integer banjiid,@Param("laoshiid") Integer laoshiid);
   
    
}