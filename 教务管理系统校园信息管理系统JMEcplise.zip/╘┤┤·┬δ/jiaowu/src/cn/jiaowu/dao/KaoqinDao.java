package cn.jiaowu.dao;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.jiaowu.entity.Chengji;
import cn.jiaowu.entity.Kaoqin;

public interface KaoqinDao {
	int deleteByPrimaryKey(Integer id);

    int insert(Kaoqin record);

    int updateByPrimaryKeySelective(Kaoqin record);
    
    List<Kaoqin> getAll(@Param("banjiid") Integer banjiid,@Param("xsmc") String xsmc,@Param("jsmc") String jsmc);
    List<Kaoqin> getAllByType(Integer type);
}