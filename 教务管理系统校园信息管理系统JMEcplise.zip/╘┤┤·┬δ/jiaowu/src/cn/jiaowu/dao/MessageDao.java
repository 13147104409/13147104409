package cn.jiaowu.dao;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.jiaowu.entity.Chengji;
import cn.jiaowu.entity.Message;

public interface MessageDao {
	int deleteByPrimaryKey(Integer id);

    int insert(Message record);

    int updateByPrimaryKeySelective(Message record);
    
    List<Message> getAll(@Param("banjiid") Integer banjiid,@Param("xsmc") String xsmc);
   
}