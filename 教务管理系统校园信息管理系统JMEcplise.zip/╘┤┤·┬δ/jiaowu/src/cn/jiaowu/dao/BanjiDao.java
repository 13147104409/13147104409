package cn.jiaowu.dao;
import java.util.List;
import cn.jiaowu.entity.Banji;

public interface BanjiDao {
	int deleteByPrimaryKey(Integer id);

    int insert(Banji record);

    Banji selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(Banji record);
    
    List<Banji> getAll();

}