package cn.jiaowu.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.jiaowu.entity.Kaoqin;
import cn.jiaowu.entity.Laoshi;
import cn.jiaowu.entity.Xuesheng;
import cn.jiaowu.services.IKaoqinService;
import cn.jiaowu.services.IXueshengService;
import cn.jiaowu.util.Const;
import cn.jiaowu.util.ServerResponse;
import cn.jiaowu.util.Const.Role;
@Controller
@RequestMapping("/kaoqin")
public class KaoqinController {

	@Autowired
	private IKaoqinService iKaoqinService;
	@Autowired
	private IXueshengService iXueshengService;

	@RequestMapping(value = "list")
	public String list(HttpSession session,Model model) {
		Integer n=(Integer)session.getAttribute(Const.CURRENT_ROLE);	
		if(n!=null && n==Role.ROLE_STUDENT){
			Xuesheng xuesheng=(Xuesheng)session.getAttribute(Const.CURRENT_USER);	
			if(xuesheng!=null){
				model.addAttribute("list", iKaoqinService.getAll(null,xuesheng.getXingming(),null));
			}
			return "manage/xuesheng/kaoqinList";
		}else{
			Laoshi laoshi=(Laoshi)session.getAttribute(Const.CURRENT_USER);	
			if(laoshi!=null){
				model.addAttribute("list", iKaoqinService.getAll(null,null,laoshi.getXingming()));
			}
			return "manage/laoshi/kaoqinList";
		}
	}
	
	@RequestMapping(value = "list2")
	public String list2(HttpSession session,Model model) {
		Integer n=(Integer)session.getAttribute(Const.CURRENT_ROLE);	
		if(n!=null && n==Role.ROLE_TEACHER){
			Laoshi laoshi=(Laoshi)session.getAttribute(Const.CURRENT_USER);	
			if(laoshi!=null){
				model.addAttribute("list", iKaoqinService.getAll(laoshi.getBanjiid(),null,null));
			}
			return "manage/laoshi/kaoqinList2";
		}
		return "manage/laoshi/kaoqinList2";
	}
	
	@RequestMapping(value = "list3")
	public String list3(HttpSession session,Model model) {
		model.addAttribute("list", iKaoqinService.getAllByType(0));
		return "manage/admin/kaoqinList3";
	}
	@RequestMapping(value = "list4")
	public String list4(HttpSession session,Model model) {
		model.addAttribute("list", iKaoqinService.getAllByType(1));
		return "manage/admin/kaoqinList4";
	}
	
	@RequestMapping(value = "addls")
	public String addls(Kaoqin kaoqin) {
		iKaoqinService.saveOrUpdate(kaoqin);
		return "redirect:list3";
	}
	@RequestMapping(value = "addxs")
	public String addxs(Kaoqin kaoqin,int xsid) {
		Xuesheng xs=iXueshengService.getXueshengDetail(xsid).getData();
		kaoqin.setXsmc(xs.getXingming());
		kaoqin.setBanjiid(xs.getBanjiid());
		iKaoqinService.saveOrUpdate(kaoqin);
		return "redirect:list4";
	}

	
	@RequestMapping(value = "update")
	public String update(Kaoqin kaoqin) {
		iKaoqinService.saveOrUpdate(kaoqin);
		return "redirect:list";
	}
	
	@RequestMapping(value = "dells{id}",method=RequestMethod.GET)
	public String dells(@PathVariable("id") int id) {
		iKaoqinService.deleteByPrimaryKey(id);
		return "redirect:list3";
	}
	
	@RequestMapping(value = "delxs{id}",method=RequestMethod.GET)
	public String delxs(@PathVariable("id") int id) {
		iKaoqinService.deleteByPrimaryKey(id);
		return "redirect:list4";
	}
	
	@RequestMapping(value = "lsdelxs{id}",method=RequestMethod.GET)
	public String lsdelxs(@PathVariable("id") int id) {
		iKaoqinService.deleteByPrimaryKey(id);
		return "redirect:list2";
	}
	
}
