package cn.jiaowu.controller;

import java.io.File;
import java.util.List;

import javax.servlet.http.HttpSession;

import jxl.Workbook;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.jiaowu.entity.Kebiao;
import cn.jiaowu.entity.Laoshi;
import cn.jiaowu.entity.Xuesheng;
import cn.jiaowu.services.IKebiaoService;
import cn.jiaowu.util.Const;
import cn.jiaowu.util.Const.Role;
@Controller
@RequestMapping("/kebiao")
public class KebiaoController {

	@Autowired
	private IKebiaoService iKebiaoService;

	@RequestMapping(value = "list")
	public String list(HttpSession session,Model model) {
		Integer n=(Integer)session.getAttribute(Const.CURRENT_ROLE);	
		if(n!=null && n==Role.ROLE_STUDENT){
			Xuesheng xuesheng=(Xuesheng)session.getAttribute(Const.CURRENT_USER);	
			if(xuesheng!=null){
				model.addAttribute("list", iKebiaoService.getAll(xuesheng.getBanjiid(),null));
			}
			return "manage/xuesheng/kebiaoList";
		}else if(n!=null && n==Role.ROLE_TEACHER){
			Laoshi laoshi=(Laoshi)session.getAttribute(Const.CURRENT_USER);	
			if(laoshi!=null){
				model.addAttribute("list", iKebiaoService.getAll(null,laoshi.getId()));
			}
			return "manage/laoshi/kebiaoList";
		}else{
			model.addAttribute("list", iKebiaoService.getAll(null,null));
			return "manage/admin/kebiaoList";
		}
	}
	
	@RequestMapping(value = "add")
	public String add(Kebiao kebiao) {
		iKebiaoService.saveOrUpdateKebiao(kebiao);
		return "redirect:list";
	}
	
	@RequestMapping(value = "update")
	public String update(Kebiao kebiao) {
		iKebiaoService.saveOrUpdateKebiao(kebiao);
		return "redirect:list";
	}
	
	
	@RequestMapping(value = "del{id}",method=RequestMethod.GET)
	public String del(@PathVariable("id") int id) {
		iKebiaoService.deleteByPrimaryKey(id);
		return "redirect:list";
	}
	
	@RequestMapping(value = "export")
	@ResponseBody
	public String export(HttpSession session) throws Exception {
		Integer n=(Integer)session.getAttribute(Const.CURRENT_ROLE);	
		if(n!=null && n==Role.ROLE_STUDENT){
			Xuesheng xuesheng=(Xuesheng)session.getAttribute(Const.CURRENT_USER);	
			if(xuesheng!=null){
				List<Kebiao> list=iKebiaoService.getAll(xuesheng.getBanjiid(),null);
				String upload = session.getServletContext()
						.getRealPath("/upload");
				File xlsFile = new File(upload + "/kb"+xuesheng.getId()+".xls");
				
				// 创建一个工作簿
				WritableWorkbook workbook = Workbook.createWorkbook(xlsFile);
				// 创建一个工作表
				WritableSheet sheet = workbook.createSheet("课表", 0);
				// 标题
				WritableFont wf_table = new WritableFont(WritableFont.ARIAL, 14,
						WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE,
						jxl.format.Colour.BLACK); // 定义格式 字体 下划线 斜体 粗体 颜色

				WritableCellFormat wcf_table1 = new WritableCellFormat(wf_table);
				wcf_table1.setBackground(jxl.format.Colour.LIGHT_GREEN);
				wcf_table1.setAlignment(jxl.format.Alignment.CENTRE);
				wcf_table1.setBorder(jxl.format.Border.ALL,
						jxl.format.BorderLineStyle.THIN, jxl.format.Colour.BLACK);

				// 内容
				WritableFont wf_content = new WritableFont(WritableFont.ARIAL, 11,
						WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE,
						jxl.format.Colour.BLACK); // 定义格式 字体 下划线 斜体 粗体 颜色
				WritableCellFormat wcf_content1 = new WritableCellFormat(wf_content);
				wcf_content1.setAlignment(jxl.format.Alignment.CENTRE);
				wcf_content1.setBorder(jxl.format.Border.ALL,
						jxl.format.BorderLineStyle.THIN, jxl.format.Colour.BLACK);

				// 列，行
				sheet.mergeCells(0, 0, 5, 0);
				// 标题
				Label content1 = new Label(0, 0, "课表", wcf_table1);
				// 写标题
				sheet.addCell(content1);

				sheet.addCell(new Label(0, 1, "编号", wcf_content1));
				sheet.addCell(new Label(1, 1, "班级名称", wcf_content1));
				sheet.addCell(new Label(2, 1, "课程名称", wcf_content1));
				sheet.addCell(new Label(3, 1, "老师名称", wcf_content1));
				sheet.addCell(new Label(4, 1, "星期", wcf_content1));
				sheet.addCell(new Label(5, 1, "时间", wcf_content1));


				for (int i = 0; i < list.size(); i++) {
					Kebiao d = list.get(i);
					// 向工作表中添加数据 //列
					sheet.addCell(new Label(0, i + 2, i + 1 + "", wcf_content1));
					sheet.addCell(new Label(1, i + 2, d.getBjmc(),
							wcf_content1));
					sheet.addCell(new Label(2, i + 2, d.getKcmc(),
							wcf_content1));
					sheet.addCell(new Label(3, i + 2, d.getLsmc(),
							wcf_content1));
					sheet.addCell(new Label(4, i + 2, d.getZhoumc(),
							wcf_content1));
					sheet.addCell(new Label(5, i + 2, d.getShijian(),
							wcf_content1));
				}
				workbook.write();
				workbook.close();
				return "upload/kb"+xuesheng.getId()+".xls";
			}
			
		}
		return "";
	}
	


}
