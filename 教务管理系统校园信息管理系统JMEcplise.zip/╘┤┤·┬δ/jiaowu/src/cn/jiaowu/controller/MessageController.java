package cn.jiaowu.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.jiaowu.entity.Message;
import cn.jiaowu.entity.Laoshi;
import cn.jiaowu.entity.Xuesheng;
import cn.jiaowu.services.IMessageService;
import cn.jiaowu.util.Const;
import cn.jiaowu.util.ServerResponse;
import cn.jiaowu.util.Const.Role;
@Controller
@RequestMapping("/message")
public class MessageController {

	@Autowired
	private IMessageService iMessageService;

	@RequestMapping(value = "list")
	public String list(HttpSession session,Model model,Integer banjiid,Integer xueshengid,Integer kechengid) {
		Integer n=(Integer)session.getAttribute(Const.CURRENT_ROLE);	
		if(n!=null && n==Role.ROLE_STUDENT){
			Xuesheng xuesheng=(Xuesheng)session.getAttribute(Const.CURRENT_USER);	
			if(xuesheng!=null){
				model.addAttribute("list", iMessageService.getAll(null,xuesheng.getXingming()));
			}
			return "manage/xuesheng/messageList";
		}else{
			Laoshi laoshi=(Laoshi)session.getAttribute(Const.CURRENT_USER);	
			if(laoshi!=null){
				model.addAttribute("list", iMessageService.getAll(laoshi.getBanjiid(),null));
			}
			return "manage/laoshi/messageList";
		}
	}
	
	@RequestMapping(value = "add")
	public String add(HttpSession session,Message message) {
		Integer n=(Integer)session.getAttribute(Const.CURRENT_ROLE);	
		if(n!=null && n==Role.ROLE_STUDENT){
			Xuesheng xuesheng=(Xuesheng)session.getAttribute(Const.CURRENT_USER);	
			if(xuesheng!=null){
				message.setXsmc(xuesheng.getXingming());
				message.setBanjiid(xuesheng.getBanjiid());
				message.setLytime(Const.getCurrentTime());
			}
		}
		iMessageService.saveOrUpdateMessage(message);
		return "redirect:list";
	}
	
	@RequestMapping(value = "update")
	public String update(HttpSession session,Message message) {
		Integer n=(Integer)session.getAttribute(Const.CURRENT_ROLE);	
		if(n!=null && n==Role.ROLE_TEACHER){
			Laoshi laoshi=(Laoshi)session.getAttribute(Const.CURRENT_USER);	
			if(laoshi!=null){
				message.setLsmc(laoshi.getXingming());
				message.setRtime(Const.getCurrentTime());
			}
		}
		iMessageService.saveOrUpdateMessage(message);
		return "redirect:list";
	}
	
	
	@RequestMapping(value = "del{id}",method=RequestMethod.GET)
	public String del(@PathVariable("id") int id) {
		iMessageService.deleteByPrimaryKey(id);
		return "redirect:list";
	}
	

}
