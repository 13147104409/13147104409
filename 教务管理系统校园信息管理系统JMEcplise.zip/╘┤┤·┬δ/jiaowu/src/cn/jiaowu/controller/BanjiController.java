package cn.jiaowu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.jiaowu.entity.Banji;
import cn.jiaowu.services.IBanjiService;
import cn.jiaowu.util.ServerResponse;
@Controller
@RequestMapping("/banji")
public class BanjiController {

	@Autowired
	private IBanjiService iBanjiService;

	@RequestMapping(value = "list")
	public String list(Model model) {
		model.addAttribute("list", iBanjiService.getAll());
		return "/manage/admin/banjiList";
	}
	
	@RequestMapping(value = "add")
	public String add(Banji banji) {
		iBanjiService.saveOrUpdateBanji(banji);
		return "redirect:list";
	}
	
	@RequestMapping(value = "update")
	public String update(Banji banji) {
		iBanjiService.saveOrUpdateBanji(banji);
		return "redirect:list";
	}
	
	@RequestMapping(value = "detail{id}",method=RequestMethod.GET)
	@ResponseBody
	public ServerResponse<Banji> detail(@PathVariable("id") int id) {
		return iBanjiService.getBanjiDetail(id);
	}
	
	@RequestMapping(value = "del{id}",method=RequestMethod.GET)
	public String del(@PathVariable("id") int id) {
		iBanjiService.deleteByPrimaryKey(id);
		return "redirect:list";
	}
	@RequestMapping(value = "listJson")
	@ResponseBody
	public ServerResponse listJson() {
		return iBanjiService.getAllBanji();
	}
}
