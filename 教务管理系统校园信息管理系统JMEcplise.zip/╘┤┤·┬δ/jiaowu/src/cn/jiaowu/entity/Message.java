package cn.jiaowu.entity;

/**
 * TChengji entity. @author MyEclipse Persistence Tools
 */

public class Message implements java.io.Serializable {

	// Fields

	private Integer id;
	private String xsmc;
	private Integer banjiid;
	private String content;
	private String lytime;
	private String reply;
	private String lsmc;
	private String rtime;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getXsmc() {
		return xsmc;
	}
	public void setXsmc(String xsmc) {
		this.xsmc = xsmc;
	}
	public Integer getBanjiid() {
		return banjiid;
	}
	public void setBanjiid(Integer banjiid) {
		this.banjiid = banjiid;
	}
	
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getReply() {
		return reply;
	}
	public void setReply(String reply) {
		this.reply = reply;
	}
	public String getLsmc() {
		return lsmc;
	}
	public void setLsmc(String lsmc) {
		this.lsmc = lsmc;
	}
	public String getRtime() {
		return rtime;
	}
	public void setRtime(String rtime) {
		this.rtime = rtime;
	}
	public String getLytime() {
		return lytime;
	}
	public void setLytime(String lytime) {
		this.lytime = lytime;
	}

	// Constructors

	

}