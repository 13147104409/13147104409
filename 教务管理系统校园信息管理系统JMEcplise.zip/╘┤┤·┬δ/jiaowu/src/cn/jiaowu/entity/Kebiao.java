package cn.jiaowu.entity;

import cn.jiaowu.util.Const;

/**
 * TChengji entity. @author MyEclipse Persistence Tools
 */

public class Kebiao implements java.io.Serializable {

	// Fields

	private Integer id;
	private Integer banjiid;
	private Integer kechengid;
	private Integer laoshiid;
	private Integer zhouid;
	private String shijian;
	
	private String bjmc;//班级名称
	private String kcmc;//课程名称
	private String lsmc;//老师名称
	private String zhoumc;//周名称
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getBanjiid() {
		return banjiid;
	}
	public void setBanjiid(Integer banjiid) {
		this.banjiid = banjiid;
	}
	public Integer getKechengid() {
		return kechengid;
	}
	public void setKechengid(Integer kechengid) {
		this.kechengid = kechengid;
	}
	public Integer getLaoshiid() {
		return laoshiid;
	}
	public void setLaoshiid(Integer laoshiid) {
		this.laoshiid = laoshiid;
	}
	public Integer getZhouid() {
		return zhouid;
	}
	public void setZhouid(Integer zhouid) {
		this.zhouid = zhouid;
	}
	public String getShijian() {
		return shijian;
	}
	public void setShijian(String shijian) {
		this.shijian = shijian;
	}
	public String getBjmc() {
		return bjmc;
	}
	public void setBjmc(String bjmc) {
		this.bjmc = bjmc;
	}
	public String getKcmc() {
		return kcmc;
	}
	public void setKcmc(String kcmc) {
		this.kcmc = kcmc;
	}
	public String getLsmc() {
		return lsmc;
	}
	public void setLsmc(String lsmc) {
		this.lsmc = lsmc;
	}
	public String getZhoumc() {
		return Const.WEEKS[this.getZhouid()];
	}
	public void setZhoumc(String zhoumc) {
		this.zhoumc = zhoumc;
	}

	
}