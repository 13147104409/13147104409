package cn.jiaowu.entity;

/**
 * TChengji entity. @author MyEclipse Persistence Tools
 */

public class Pingjia implements java.io.Serializable {

	// Fields

	private Integer id;
	private String xsmc;
	private Integer banjiid;
	private String jsmc;
	private String shijian;
	private String result;
	private Integer type;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getXsmc() {
		return xsmc;
	}
	public void setXsmc(String xsmc) {
		this.xsmc = xsmc;
	}
	public Integer getBanjiid() {
		return banjiid;
	}
	public void setBanjiid(Integer banjiid) {
		this.banjiid = banjiid;
	}
	public String getJsmc() {
		return jsmc;
	}
	public void setJsmc(String jsmc) {
		this.jsmc = jsmc;
	}
	public String getShijian() {
		return shijian;
	}
	public void setShijian(String shijian) {
		this.shijian = shijian;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	
}