package cn.jiaowu.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

public class Const {

	public static final String CURRENT_USER = "currentUser";
	public static final String CURRENT_ROLE = "currentRole";
	public static final String ROOT = "/jiaowu/";
	
	public static String getCurrentTime(){
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(new Date());
	}
	
	public interface Role {
		int ROLE_ADMIN = 0;// 管理员
		int ROLE_TEACHER = 1;// 教师
		int ROLE_STUDENT = 2; // 普通用户
	}

	public static final String[] WEEKS = { "星期日", "星期一", "星期二", "星期三", "星期四",
			"星期五", "星期六" };

}
