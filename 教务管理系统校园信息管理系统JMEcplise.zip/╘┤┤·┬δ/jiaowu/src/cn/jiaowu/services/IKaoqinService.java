package cn.jiaowu.services;

import java.util.List;
import cn.jiaowu.entity.Chengji;
import cn.jiaowu.entity.Kaoqin;
import cn.jiaowu.util.ServerResponse;

public interface IKaoqinService {

	void saveOrUpdate(Kaoqin record);

    void deleteByPrimaryKey(Integer id);
    
    List<Kaoqin> getAll(Integer banjiid,String xsmc,String jsmc);
    List<Kaoqin> getAllByType(Integer type);
}
