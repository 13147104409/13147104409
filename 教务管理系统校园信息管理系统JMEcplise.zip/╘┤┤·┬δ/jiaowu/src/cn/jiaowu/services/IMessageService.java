package cn.jiaowu.services;

import java.util.List;
import cn.jiaowu.entity.Message;


public interface IMessageService {

	void saveOrUpdateMessage(Message chengji);

    void deleteByPrimaryKey(Integer id);
    
    List<Message> getAll(Integer banjiid,String xsmc);
    
}
