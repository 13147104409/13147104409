package cn.jiaowu.services;

import java.util.List;
import cn.jiaowu.entity.Chengji;
import cn.jiaowu.entity.Kaoqin;
import cn.jiaowu.entity.Pingjia;
import cn.jiaowu.util.ServerResponse;

public interface IPingjiaService {

	void saveOrUpdate(Pingjia record);

    void deleteByPrimaryKey(Integer id);
    
    List<Pingjia> getAll(Integer banjiid,String xsmc,String jsmc);
    List<Pingjia> getAllByType(Integer type);
}
