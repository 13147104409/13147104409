package cn.jiaowu.services;

import java.util.List;
import cn.jiaowu.entity.Chengji;
import cn.jiaowu.entity.Kebiao;
import cn.jiaowu.util.ServerResponse;

public interface IKebiaoService {

	void saveOrUpdateKebiao(Kebiao kebiao);

    void deleteByPrimaryKey(Integer id);
    
    List<Kebiao> getAll(Integer banjiid,Integer laoshiId);
    
}
