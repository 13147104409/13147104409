package cn.jiaowu.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.jiaowu.dao.PingjiaDao;
import cn.jiaowu.entity.Pingjia;
import cn.jiaowu.services.IPingjiaService;
import java.util.List;

@Service("iPingjiaService")
public class PingjiaServiceImpl implements IPingjiaService {
	@Autowired
	private PingjiaDao pingjiaDao;

	public void saveOrUpdate(Pingjia record) {
		int rowCount = 0;
		if (record != null) {
			if (record.getId() != null) {
				rowCount = pingjiaDao.updateByPrimaryKeySelective(record);
			} else {
				rowCount = pingjiaDao.insert(record);
			}
		}
	}

	public List<Pingjia> getAll(Integer banjiid,String xsmc,String jsmc) {
		// TODO Auto-generated method stub
		return pingjiaDao.getAll(banjiid,xsmc,jsmc);
	}

	public void deleteByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		int rowCount = pingjiaDao.deleteByPrimaryKey(id);
	}

	public List<Pingjia> getAllByType(Integer type) {
		// TODO Auto-generated method stub
		return pingjiaDao.getAllByType(type);
	}
	
	
}
