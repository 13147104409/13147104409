package cn.jiaowu.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import cn.jiaowu.dao.BanjiDao;
import cn.jiaowu.entity.Banji;
import cn.jiaowu.services.IBanjiService;
import cn.jiaowu.util.ResponseCode;
import cn.jiaowu.util.ServerResponse;

import java.util.ArrayList;
import java.util.List;

@Service("iBanjiService")
public class BanjiServiceImpl implements IBanjiService {
	@Autowired
	private BanjiDao banjiDao;

	public void saveOrUpdateBanji(Banji banji) {
		int rowCount = 0;
		if (banji != null) {
			if (banji.getId() != null) {
				rowCount = banjiDao.updateByPrimaryKeySelective(banji);
			} else {
				banji.setDel(0);//初始时设置为0
				rowCount = banjiDao.insert(banji);
			}
		}
	}

	public ServerResponse<Banji> getBanjiDetail(Integer id) {
		if (id == null) {
			return ServerResponse.createByErrorCodeMessage(
					ResponseCode.ILLEGAL_ARGUMENT.getCode(),
					ResponseCode.ILLEGAL_ARGUMENT.getDesc());
		}
		Banji banji = banjiDao.selectByPrimaryKey(id);
		if (banji == null) {
			return ServerResponse.createByErrorMessage("查询结果为空");
		}
		return ServerResponse.createBySuccess(banji);
	}

	public List<Banji> getAll() {
		// TODO Auto-generated method stub
		return banjiDao.getAll();
	}

	public void deleteByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		int rowCount = banjiDao.deleteByPrimaryKey(id);
	}
	
	public ServerResponse getAllBanji() {
		return ServerResponse.createBySuccess(banjiDao.getAll());
	}

}