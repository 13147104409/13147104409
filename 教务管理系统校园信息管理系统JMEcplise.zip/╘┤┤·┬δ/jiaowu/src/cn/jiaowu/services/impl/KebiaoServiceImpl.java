package cn.jiaowu.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.jiaowu.dao.KebiaoDao;
import cn.jiaowu.entity.Kebiao;
import cn.jiaowu.services.IKebiaoService;
import cn.jiaowu.util.ResponseCode;
import cn.jiaowu.util.ServerResponse;
import java.util.List;

@Service("iKebiaoService")
public class KebiaoServiceImpl implements IKebiaoService {
	@Autowired
	private KebiaoDao kebiaoDao;

	public void saveOrUpdateKebiao(Kebiao kebiao) {
		int rowCount = 0;
		if (kebiao != null) {
			if (kebiao.getId() != null) {
				rowCount = kebiaoDao.updateByPrimaryKeySelective(kebiao);
			} else {
				rowCount = kebiaoDao.insert(kebiao);
			}
		}
	}

	public List<Kebiao> getAll(Integer banjiid,Integer laoshiId) {
		// TODO Auto-generated method stub
		return kebiaoDao.getAll(banjiid,laoshiId);
	}

	public void deleteByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		int rowCount = kebiaoDao.deleteByPrimaryKey(id);
	}

	

}
