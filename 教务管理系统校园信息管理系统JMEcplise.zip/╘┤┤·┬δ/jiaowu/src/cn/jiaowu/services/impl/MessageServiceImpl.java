package cn.jiaowu.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.jiaowu.dao.MessageDao;
import cn.jiaowu.entity.Message;
import cn.jiaowu.services.IMessageService;
import cn.jiaowu.util.Const;
import cn.jiaowu.util.ResponseCode;
import cn.jiaowu.util.ServerResponse;
import java.util.List;

@Service("iMessageService")
public class MessageServiceImpl implements IMessageService {
	@Autowired
	private MessageDao messageDao;

	public void saveOrUpdateMessage(Message message) {
		int rowCount = 0;
		if (message != null) {
			if (message.getId() != null) {
				rowCount = messageDao.updateByPrimaryKeySelective(message);
			} else {
				rowCount = messageDao.insert(message);
			}
		}
	}

	public List<Message> getAll(Integer banjiid,String xsmc) {
		// TODO Auto-generated method stub
		return messageDao.getAll(banjiid,xsmc);
	}

	public void deleteByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		int rowCount = messageDao.deleteByPrimaryKey(id);
	}
	
}
