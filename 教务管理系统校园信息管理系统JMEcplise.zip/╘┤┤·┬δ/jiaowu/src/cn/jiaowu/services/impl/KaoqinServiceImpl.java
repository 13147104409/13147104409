package cn.jiaowu.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.jiaowu.dao.KaoqinDao;
import cn.jiaowu.entity.Kaoqin;
import cn.jiaowu.services.IKaoqinService;
import java.util.List;

@Service("iKaoqinService")
public class KaoqinServiceImpl implements IKaoqinService {
	@Autowired
	private KaoqinDao kaoqinDao;

	public void saveOrUpdate(Kaoqin record) {
		int rowCount = 0;
		if (record != null) {
			if (record.getId() != null) {
				rowCount = kaoqinDao.updateByPrimaryKeySelective(record);
			} else {
				rowCount = kaoqinDao.insert(record);
			}
		}
	}

	public List<Kaoqin> getAll(Integer banjiid,String xsmc,String jsmc) {
		// TODO Auto-generated method stub
		return kaoqinDao.getAll(banjiid,xsmc,jsmc);
	}

	public void deleteByPrimaryKey(Integer id) {
		// TODO Auto-generated method stub
		int rowCount = kaoqinDao.deleteByPrimaryKey(id);
	}

	public List<Kaoqin> getAllByType(Integer type) {
		// TODO Auto-generated method stub
		return kaoqinDao.getAllByType(type);
	}
	
	
}
