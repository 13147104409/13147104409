package cn.jiaowu.services;

import java.util.List;
import cn.jiaowu.entity.Banji;
import cn.jiaowu.util.ServerResponse;

public interface IBanjiService {

	void saveOrUpdateBanji(Banji banji);

    ServerResponse<Banji> getBanjiDetail(Integer id);
    
    ServerResponse getAllBanji();

    List<Banji> getAll();
    
    void deleteByPrimaryKey(Integer id);
}
